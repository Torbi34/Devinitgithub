import java.util.Scanner;

public class TD3 {

    

    public static void main (String[]args ){

        }
}
