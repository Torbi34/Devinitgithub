public class TD1 {

    public static void exercice5_1 (){
        //PR : rien
        // Action : demande à l’utilisateur de saisir un entier n, puis de saisir n entiers.
        // Le programme affiche alors la somme des n entiers saisis.
        // Strategie : boucle for

        int somme = 0 ;
        int nb=0;

        Ut.afficherSL("Saisir un nombre");
        int n = Ut.saisirEntier();

        for(int i = 0 ; i <n ; i++ ){
            Ut.afficherSL("Saisir un nombre");
            nb = Ut.saisirEntier();
            somme+=nb;
        }

        Ut.afficherSL("la somme des nombres est " + somme);

    }

    public static void exercice5_2 (){
        //PR : rien
        // Action : demande à l’utilisateur de saisir des entiers jusqu’à ce que l’utilisateur saisisse la valeur 0.
        // Le programme affiche alors le nombre d’entiers non nuls qui ont été saisis et leur somme.
        // Strategie : boucle while


        int somme = 0 ;
        int effectif=0;
        int nbVal=0;

        Ut.afficherSL("Saisir un nombre (arrete lors de la saisie de 0)");
        nbVal = Ut.saisirEntier();
        while(nbVal>0){
            effectif++;
            somme+=nbVal;
            Ut.afficherSL("Saisir un nombre (arrete lors de la saisie de 0)");
            nbVal = Ut.saisirEntier();
        }

        Ut.afficherSL("la somme des nombres est " + somme);
        Ut.afficherSL("l'effectif des nombres est " + effectif);
    }

    public static void main (String[]args ){

        //nom des procédures / fonctions que vous souhaitez executer

        exercice5_1();
        exercice5_2();
    }


}
